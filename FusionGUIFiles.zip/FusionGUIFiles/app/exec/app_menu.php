<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Command";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Befehle";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Befehle";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Comando";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Comando";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Command";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Commande";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Comando";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Polecenie";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Comandos";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Comandos";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Выполнение команд";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Kommando";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Команди";
	$apps[$x]['menu'][$y]['uuid'] = "06493580-9131-ce57-23cd-d42d69dd8526";
	$apps[$x]['menu'][$y]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/exec/exec.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>