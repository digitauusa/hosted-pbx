<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Call Broadcast";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Rundrufe";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Rundrufe";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Llamada Broadcast";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Campagne d'Appels";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Chiamate Multiple";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Rozsyłanie rozmów";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Chamada em broadcast";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Chamada em Broadcast";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Массовые вызовы";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Samtalsdistribution";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Трансляція дзвінка";
	$apps[$x]['menu'][$y]['uuid'] = "50153bbf-78c5-b49e-7bd9-4b3e4b1134e6";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['path'] = "/app/call_broadcast/call_broadcast.php";

?>
