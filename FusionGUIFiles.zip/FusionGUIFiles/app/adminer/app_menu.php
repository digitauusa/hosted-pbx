<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Adminer";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Adminer";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Adminer";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Administrador";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Admin BDD";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Adminer";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Adminer";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Administrador";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Администрирование БД";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = "1f59d07b-b4f7-4f9e-bde9-312cf491d66e";
	$apps[$x]['menu'][$y]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
	$apps[$x]['menu'][$y]['category'] = "external";
	$apps[$x]['menu'][$y]['icon'] = "glyphicon-new-window";
	$apps[$x]['menu'][$y]['path'] = "/app/adminer/index.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>