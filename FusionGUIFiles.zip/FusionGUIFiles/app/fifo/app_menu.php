<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Queues";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Warteschlangen";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "Warteschlangen";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Warteschlangen";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Colas";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Colas";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Queues";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Code";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Kolejki";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Filas";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Очереди";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = "c535ac0b-1da1-0f9c-4653-7934c6f4732c";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/dialplans/dialplans.php?app_uuid=16589224-c876-aeb3-f59f-523a1c0801f7";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
