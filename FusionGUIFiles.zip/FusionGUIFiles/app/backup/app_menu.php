<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Backup";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Datensicherung";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Datensicherung";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Sauvegarde";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Kopie zapasowe";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Backup";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Резервное копирование";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Backup";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Резервна копія";
	$apps[$x]['menu'][$y]['uuid'] = "7e174c3c-e494-4bb0-a52a-4ea55209ffeb";
	$apps[$x]['menu'][$y]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/backup/index.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>