<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Log Viewer";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Log Betrachter";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Log Betrachter";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Visor de eventos";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Voir les Logs";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Log Viewer";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Podgląd logów";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Visualizar Log";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Visualizar Log";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Просмотр логов";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Log Viewer ";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Логи";
	$apps[$x]['menu'][$y]['uuid'] = "781ebbec-a55a-9d60-f7bb-f54ab2ee4e7e";
	$apps[$x]['menu'][$y]['parent_uuid'] = "0438b504-8613-7887-c420-c837ffb20cb1";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/log_viewer/log_viewer.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>