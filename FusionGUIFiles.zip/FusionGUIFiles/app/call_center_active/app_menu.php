<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Active Call Center";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Aktive Callcenter";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Aktive Callcenter";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Centro de Llamada Activo";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Centre d'Appels Active";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Centre d'Appel Actif";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Call Center Attivi";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Aktywność w Call Center ";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Call Center ativos";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Centro de Chamadas Activo";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Активные Колл-центры";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Aktivt Call Center";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = "7fb0dd87-e984-9980-c512-2c76b887aeb2";
	$apps[$x]['menu'][$y]['parent_uuid'] = "0438b504-8613-7887-c420-c837ffb20cb1";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/call_center_active/call_center_queue.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>