<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Call Routing";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Call Routing";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "Call Routing";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Call Routing";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "enrutamiento de llamadas";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "routage des appels";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "routage des appels";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Istradamento Chiamate";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "roteamento de chamadas";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Roteamento de chamadas";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Маршрутизация вызовов";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";

	$apps[$x]['menu'][$y]['uuid'] = "4e4df00b-aafb-45a8-82c1-cdabc921889c";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/calls/calls.php";
	$apps[$x]['menu'][$y]['groups'][] = "user";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>