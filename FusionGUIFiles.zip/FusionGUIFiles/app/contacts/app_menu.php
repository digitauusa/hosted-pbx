<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Contacts";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Kontakte";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Kontakte";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Contactos";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Contacts";
	$apps[$x]['menu'][$y]['title']['he-il'] = "אנשי קשר";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Contatti";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Kontakty";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Contatos";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Contactos";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Контакты";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Kontakter";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Контакти";
	$apps[$x]['menu'][$y]['uuid'] = "f14e6ab6-6565-d4e6-cbad-a51d2e3e8ec6";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/contacts/contacts.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>