## Recommended Firmware and Naming Convention for Htek.
