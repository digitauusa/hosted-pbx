<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Active Queues";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Aktive Warteschlangen";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Aktive Warteschlangen";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Colas activas";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Colas activas";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Queues actives";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Queues Actives";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Code Attive";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Aktywne kolejki";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Filas ativas";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Filas Activas";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Активные Очереди";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Aktiva Köer";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Активні черги";
	$apps[$x]['menu'][$y]['uuid'] = "450f1225-9187-49ac-a119-87bc26025f7d";
	$apps[$x]['menu'][$y]['parent_uuid'] = "0438b504-8613-7887-c420-c837ffb20cb1";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/fifo_list/fifo_list.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>