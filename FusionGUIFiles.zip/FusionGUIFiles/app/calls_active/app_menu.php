<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Active Calls";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Aktive Gespräche";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Aktive Gespräche";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Llamadas Activas";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Appels en cours";
	$apps[$x]['menu'][$y]['title']['he-il'] = "שיחות פעילות";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Chiamate Attive";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Aktywne połączenia";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Chamadas ativas";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Chamadas Activas";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Активные вызовы";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Aktiva samtal";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Активні дзвінки";
	$apps[$x]['menu'][$y]['uuid'] = "eba3d07f-dd5c-6b7b-6880-493b44113ade";
	$apps[$x]['menu'][$y]['parent_uuid'] = "0438b504-8613-7887-c420-c837ffb20cb1";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/calls_active/calls_active.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";

?>