<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = 'Conference Profiles';
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = 'Konferenzprofile';
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = 'Konferenzprofile';
	$apps[$x]['menu'][$y]['title']['es-cl'] = "";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Profili Conferenza";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = 'Конференции Профили';
	$apps[$x]['menu'][$y]['title']['sv-se'] = "";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = '6ebe7b9c-e964-4349-a002-288ea6ad08ca';
	$apps[$x]['menu'][$y]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
	$apps[$x]['menu'][$y]['category'] = 'internal';
	$apps[$x]['menu'][$y]['path'] = '/app/conference_profiles/conference_profiles.php';
	$apps[$x]['menu'][$y]['groups'][] = 'superadmin';
	//$apps[$x]['menu'][$y]['groups'][] = 'admin';
	//$apps[$x]['menu'][$y]['groups'][] = 'user';

?>