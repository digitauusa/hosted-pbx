<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Music on Hold";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Wartemusik";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Wartemusik";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Música en espera";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Musique d'attente";
	$apps[$x]['menu'][$y]['title']['he-il'] = "מוסיקה בהמתנה";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Musica d'attesa";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Muzyka na czekanie";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Música de espera";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Musica em Espera";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Музыка на удержании";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Väntmusik";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Музика на утриманні";
	$apps[$x]['menu'][$y]['uuid'] = "1cd1d6cb-912d-db32-56c3-e0d5699feb9d";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/music_on_hold/music_on_hold.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";

?>