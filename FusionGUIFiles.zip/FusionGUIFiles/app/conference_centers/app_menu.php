<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Conference Centers";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Konferenz Zentrale";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Konferenz Zentrale";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Cent. de Conferencias";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Centre de Conférences";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Centro Conferenze";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Centrum Konferencyjne";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Centro de Conferência";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Conferencias";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Конференц-центр";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Konferenscenter";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Конференц-центр";
	$apps[$x]['menu'][$y]['uuid'] = "95f88726-4706-43f0-b52b-9504a0b8046f";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/conference_centers/conference_centers.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "user";

?>
