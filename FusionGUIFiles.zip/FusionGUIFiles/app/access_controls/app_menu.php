<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Access Controls";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "عناصر التحكم في الوصول";
	$apps[$x]['menu'][$y]['title']['de-at'] = " Zugriffskontrolle";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = " Zugriffskontrolle";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Controles de acceso";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Contrôles d'accès";
	$apps[$x]['menu'][$y]['title']['he-il'] = "בקרת גישה";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Controlli Accesso";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Kontrola dostępu";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Controles de Acesso";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Controles de Acesso";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "Controale de acces";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Контроль доступа";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "контроль доступу";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Åtkomstkontroll";
	$apps[$x]['menu'][$y]['uuid'] = "bd47c972-5498-4541-b44a-d4bbfac69496";
	$apps[$x]['menu'][$y]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/access_controls/access_controls.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>