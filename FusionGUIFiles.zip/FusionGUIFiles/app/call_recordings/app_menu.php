<?php

$apps[$x]['menu'][0]['title']['en-us'] = 'Call Recordings';
$apps[$x]['menu'][0]['title']['es-cl'] = '';
$apps[$x]['menu'][0]['title']['fr-fr'] = '';
$apps[$x]['menu'][0]['title']['fr-ca'] = '';
$apps[$x]['menu'][0]['title']['pl'] = '';
$apps[$x]['menu'][0]['title']['sv-se'] = '';
$apps[$x]['menu'][0]['title']['uk'] = '';
$apps[$x]['menu'][0]['title']['de-at'] = '';
$apps[$x]['menu'][0]['uuid'] = 'd5b7bd0e-5e56-4d87-b2d5-7d7b2f7307ef';
$apps[$x]['menu'][0]['parent_uuid'] = 'fd29e39c-c936-f5fc-8e2b-611681b266b5';
$apps[$x]['menu'][0]['category'] = 'internal';
$apps[$x]['menu'][0]['path'] = '/app/call_recordings/call_recordings.php';
$apps[$x]['menu'][0]['groups'][] = 'superadmin';
//$apps[$x]['menu'][0]['groups'][] = 'admin';
//$apps[$x]['menu'][0]['groups'][] = 'user';

?>