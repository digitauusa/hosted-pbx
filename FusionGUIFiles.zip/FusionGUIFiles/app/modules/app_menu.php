<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Modules";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Module";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Module";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Módulos";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Modules";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Moduli";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Moduły";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Módulos";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Modulos";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Модули";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Moduler";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Модулі";
	$apps[$x]['menu'][$y]['uuid'] = "49fdb4e1-5417-0e7a-84b3-eb77f5263ea7";
	$apps[$x]['menu'][$y]['parent_uuid'] = "594d99c5-6128-9c88-ca35-4b33392cec0f";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/modules/modules.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>