<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Destinations";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "جهات الأتصال";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Ziele";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Ziele";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Destinos";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Destinos";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Cibler";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Destinations";
	$apps[$x]['menu'][$y]['title']['he-il'] = "יעד";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Destinazioni";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Destynacje";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Destinos";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Destinos";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "Destinații";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Направления";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Destinationer";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Номери";
	$apps[$x]['menu'][$y]['uuid'] = "fd2a708a-ff03-c707-c19d-5a4194375eba";
	$apps[$x]['menu'][$y]['parent_uuid'] = "b94e8bd9-9eb5-e427-9c26-ff7a6c21552a";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/destinations/destinations.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";

?>
