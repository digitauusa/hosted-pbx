<?php

$apps[$x]['menu'][0]['title']['en-us'] = 'Email Templates';
$apps[$x]['menu'][0]['title']['es-cl'] = '';
$apps[$x]['menu'][0]['title']['fr-fr'] = '';
$apps[$x]['menu'][0]['title']['fr-ca'] = '';
$apps[$x]['menu'][0]['title']['pl'] = '';
$apps[$x]['menu'][0]['title']['sv-se'] = '';
$apps[$x]['menu'][0]['title']['uk'] = '';
$apps[$x]['menu'][0]['title']['de-at'] = '';
$apps[$x]['menu'][0]['uuid'] = '5e548de3-ff1a-44e4-a2e6-f3917dac85a3';
$apps[$x]['menu'][0]['parent_uuid'] = '594d99c5-6128-9c88-ca35-4b33392cec0f';
$apps[$x]['menu'][0]['category'] = 'internal';
$apps[$x]['menu'][0]['path'] = '/app/email_templates/email_templates.php';
$apps[$x]['menu'][0]['groups'][] = 'superadmin';
//$apps[$x]['menu'][0]['groups'][] = 'admin';

?>
