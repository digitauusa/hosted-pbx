<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "IVR Menus";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Automatische Vermittlung";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Automatische Vermittlung";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Menu SVI";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Menu IVR";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Zapowiedzi głosowe (IVR)";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Menu de IVR";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Menu de IVR";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Голосовые меню (IVR)";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "IVR Meny";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = "72259497-a67b-e5aa-cac2-0f2dcef16308";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/ivr_menus/ivr_menus.php";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>
