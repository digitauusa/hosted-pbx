<?php

$apps[$x]['menu'][0]['title']['en-us'] = 'Transactions';
$apps[$x]['menu'][0]['title']['es-cl'] = '';
$apps[$x]['menu'][0]['title']['fr-fr'] = '';
$apps[$x]['menu'][0]['title']['fr-ca'] = '';
$apps[$x]['menu'][0]['title']['pl'] = '';
$apps[$x]['menu'][0]['title']['ru-ru'] = 'Изменения в БД';
$apps[$x]['menu'][0]['title']['sv-se'] = '';
$apps[$x]['menu'][0]['title']['uk'] = '';
$apps[$x]['menu'][0]['title']['de-de'] = 'Datenbank Transaktionen';
$apps[$x]['menu'][0]['title']['de-at'] = 'Datenbank Transaktionen';
$apps[$x]['menu'][0]['uuid'] = 'ffc57bea-df1d-4099-b7e5-835d68f09006';
$apps[$x]['menu'][0]['parent_uuid'] = '594d99c5-6128-9c88-ca35-4b33392cec0f';
$apps[$x]['menu'][0]['category'] = 'internal';
$apps[$x]['menu'][0]['path'] = '/app/database_transactions/database_transactions.php';
$apps[$x]['menu'][0]['groups'][] = 'superadmin';
//$apps[$x]['menu'][0]['groups'][] = 'admin';
//$apps[$x]['menu'][0]['groups'][] = 'user';

?>