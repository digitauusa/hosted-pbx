<?php

	//$apps[$x]['menu'][0]['title']['en-us'] = "Users";
	//$apps[$x]['menu'][0]['title']['de-de'] = "Benutzer";
	//$apps[$x]['menu'][0]['title']['de-at'] = "Benutzer";
	//$apps[$x]['menu'][0]['title']['ru-ru'] = "Пользователи";
	//$apps[$x]['menu'][0]['uuid'] = "8d4920dc-7077-47ab-86c7-cc377ba2a5f5";
	//$apps[$x]['menu'][0]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	//$apps[$x]['menu'][0]['category'] = "internal";
	//$apps[$x]['menu'][0]['path'] = "/app/meeting_users/meeting_users.php";
	//$apps[$x]['menu'][0]['groups'][] = "user";
	//$apps[$x]['menu'][0]['groups'][] = "admin";
	//$apps[$x]['menu'][0]['groups'][] = "superadmin";

?>
