<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Fax Server";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Faxserver";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "Faxserver";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Faxserver";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Servidor de Fax";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "Servidor de Fax";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Serveur du fax";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "Serveur Fax";
	$apps[$x]['menu'][$y]['title']['he-il'] = "שרת פקסים";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Fax Server";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Serwer faksowy";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Servidor de Fax";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "Servidor de Fax";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "Server Fax";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Сервер факсов";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Fax Server";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "";
	$apps[$x]['menu'][$y]['uuid'] = "9c9642e4-2b9b-2785-18d0-6c0a4ede2b2f";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/fax/fax.php";
	$apps[$x]['menu'][$y]['groups'][] = "user";
	$apps[$x]['menu'][$y]['groups'][] = "admin";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";

?>