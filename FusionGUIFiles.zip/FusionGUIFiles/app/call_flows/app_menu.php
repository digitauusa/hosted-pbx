<?php

	$y=0;
	$apps[$x]['menu'][$y]['title']['en-us'] = "Call Flows";
	$apps[$x]['menu'][$y]['title']['ar-eg'] = "";
	$apps[$x]['menu'][$y]['title']['de-at'] = "Anruf Steuerung";
	$apps[$x]['menu'][$y]['title']['de-ch'] = "";
	$apps[$x]['menu'][$y]['title']['de-de'] = "Anruf Steuerung";
	$apps[$x]['menu'][$y]['title']['es-cl'] = "Flujo de Llamada";
	$apps[$x]['menu'][$y]['title']['es-mx'] = "";
	$apps[$x]['menu'][$y]['title']['fr-ca'] = "Circulation d'Appel";
	$apps[$x]['menu'][$y]['title']['fr-fr'] = "cinématiques d'Appel";
	$apps[$x]['menu'][$y]['title']['he-il'] = "";
	$apps[$x]['menu'][$y]['title']['it-it'] = "Deviatori di Chiamata";
	$apps[$x]['menu'][$y]['title']['nl-nl'] = "";
	$apps[$x]['menu'][$y]['title']['pl-pl'] = "Przepływ rozmów";
	$apps[$x]['menu'][$y]['title']['pt-br'] = "Fluxo de chamadas";
	$apps[$x]['menu'][$y]['title']['pt-pt'] = "";
	$apps[$x]['menu'][$y]['title']['ro-ro'] = "";
	$apps[$x]['menu'][$y]['title']['ru-ru'] = "Переключатель вызовов";
	$apps[$x]['menu'][$y]['title']['sv-se'] = "Samtalsflöden";
	$apps[$x]['menu'][$y]['title']['uk-ua'] = "Потоки дзвінків";
	$apps[$x]['menu'][$y]['uuid'] = "b0939384-7055-44e8-8b4c-9f72293e1878";
	$apps[$x]['menu'][$y]['parent_uuid'] = "fd29e39c-c936-f5fc-8e2b-611681b266b5";
	$apps[$x]['menu'][$y]['category'] = "internal";
	$apps[$x]['menu'][$y]['path'] = "/app/call_flows/call_flows.php";
	$apps[$x]['menu'][$y]['groups'][] = "superadmin";
	$apps[$x]['menu'][$y]['groups'][] = "admin";

?>